import streamlit as st
import joblib

# -----------------------------
# Load the trained pipeline
# -----------------------------
@st.cache_resource
def load_model():
    # This should be the tuned pipeline you saved earlier:
    # joblib.dump(best_lr, "spam_classifier_pipeline.pkl")
    model = joblib.load("spam_classifier_pipeline.pkl")
    return model

model = load_model()

# -----------------------------
# Global settings
# -----------------------------
st.set_page_config(
    page_title="Email Spam Detector",
    page_icon="📧",
    layout="centered"
)

SPAM_THRESHOLD = 0.40  # custom threshold to make model more spam-sensitive

# -----------------------------
# Navbar (Sidebar menu)
# -----------------------------
st.sidebar.title("Menu")
page = st.sidebar.radio(
    "Go to",
    ["Home", "Detect", "Theory", "Contact"]
)

# =============================
# HOME PAGE
# =============================
if page == "Home":
    st.title("📧 Email Spam Detection using NLP & ML")
    st.write(
        """
        This project is a **Machine Learning based Email Spam Detector** built using:

        - **NLP (Natural Language Processing)** for text cleaning and feature extraction  
        - **TF-IDF (Term Frequency–Inverse Document Frequency)** to convert text into numerical vectors  
        - **Logistic Regression (tuned)** as the final classifier  

        ### 🔍 What does this app do?

        - Takes an email (or message) as input  
        - Analyzes its content using a trained ML model  
        - Predicts whether it is:
          - ✅ **Not Spam (Ham)**, or  
          - 🚨 **Spam**

        ### 🎯 Main Objectives

        - Detect spam messages automatically  
        - Demonstrate a full ML pipeline:
          - Data preprocessing  
          - Feature extraction (TF-IDF)  
          - Model training & hyper-parameter tuning  
          - Deployment with Streamlit front-end  

        You can use the **Detect** page from the left menu to try out some examples.
        """
    )


# =============================
# DETECT PAGE
# =============================
elif page == "Detect":
    st.title("🔍 Spam Detector")

    st.write(
        "Paste the **email content** below and the model will predict whether it is "
        "**Spam** or **Not Spam**."
    )

    email_text = st.text_area(
        "✉️ Email Content",
        placeholder="Paste the email (or message) text here...",
        height=200
    )

    if st.button("Check Spam"):
        if not email_text.strip():
            st.warning("Please enter some text to classify.")
        else:
            # Model is a Pipeline: [TFIDF] -> [LogisticRegression]
            proba = model.predict_proba([email_text])[0]   # [P(ham), P(spam)]
            ham_prob = float(proba[0])
            spam_prob = float(proba[1])

            # Custom decision rule using threshold
            if spam_prob >= SPAM_THRESHOLD:
                st.error(
                    f"🚨 This looks like **SPAM** "
                    f"(spam probability: {spam_prob * 100:.2f}%, "
                    f"threshold: {SPAM_THRESHOLD * 100:.0f}%)"
                )
            else:
                st.success(
                    f"✅ This looks like **NOT SPAM** "
                    f"(ham probability: {ham_prob * 100:.2f}%, "
                    f"threshold for spam: {SPAM_THRESHOLD * 100:.0f}%)"
                )

            # Show probabilities clearly
            st.subheader("Prediction probabilities")
            st.write(f"**Not Spam (Ham):** {ham_prob * 100:.2f}%")
            st.write(f"**Spam:** {spam_prob * 100:.2f}%")

            # Simple bar to visualize spam probability
            st.write("Spam probability bar:")
            st.progress(spam_prob)

# =============================
# THEORY PAGE
# =============================
elif page == "Theory":
    st.title("📚 Theory Behind the Project")

    st.subheader("1️⃣ Problem Definition")
    st.write(
        """
        The goal is to build a model that can automatically classify a given message as:
        - **0 → Ham (Not spam)**
        - **1 → Spam**

        This is a **supervised binary classification** problem using text data.
        """
    )

    st.subheader("2️⃣ NLP Preprocessing")
    st.write(
        """
        Before training the model, the raw text is cleaned:

        - **Lowercasing** – convert all text to lowercase  
        - **Removing noise** – URLs, email IDs, numbers, punctuation  
        - **Tokenization** – splitting text into words (tokens)  
        - **Stopword removal** – removing common words like *"the", "is", "and"*  
        - (Optional) **Stemming/Lemmatization** – reducing words to their base form  

        This makes the text more structured and easier for the model to learn from.
        """
    )

    st.subheader("3️⃣ Feature Extraction with TF-IDF")
    st.write(
        """
        Machines can’t directly understand text, so we convert messages into numbers using **TF-IDF**:

        - **TF (Term Frequency):** how often a word appears in a message  
        - **IDF (Inverse Document Frequency):** how rare that word is across all messages  

        TF-IDF gives higher weight to words that are:
        - frequent in a given message  
        - but not too common in all messages  

        This helps the model focus on important words like **“free”, “win”, “offer”, “click”**, etc.
        """
    )

    st.subheader("4️⃣ Model: Logistic Regression (with Hyperparameter Tuning)")
    st.write(
        """
        We use **Logistic Regression**, a linear model that outputs a probability between 0 and 1.

        - Input: TF-IDF vector of the message  
        - Output: Probability of being **Spam**  

        We applied **hyperparameter tuning** (GridSearchCV) to find the best:
        - `ngram_range` (unigrams / bigrams)  
        - `max_df`, `min_df`  
        - `max_features`  
        - `C`, `class_weight` for Logistic Regression  

        This improved:
        - overall accuracy to around **98%+**  
        - **spam recall** (catching more spam messages)
        """
    )

    st.subheader("5️⃣ Custom Decision Threshold")
    st.write(
        f"""
        By default, a model predicts **Spam** if P(spam) > 0.5.  
        In this app, we use a custom **spam threshold of {int(SPAM_THRESHOLD * 100)}%**:

        - If `P(spam) ≥ {int(SPAM_THRESHOLD * 100)}%` → classify as **Spam**  
        - Otherwise → classify as **Not Spam**  

        This makes the model more sensitive to spam and helps catch more suspicious messages.
        """
    )

# =============================
# CONTACT PAGE
# =============================
elif page == "Contact":
    st.title("📞 Contact Information")

    st.write(
        """
        You can customize this section with your own details.

        **Developer:**  
        - Name: *Group-3*  
        - Email: *group3@gmail.com*  
        - LinkedIn: *https://www.linkedin.com/in/teja-reddy-333a69291/*

        **Project Details:**  
        - Project: Email Spam Detection using NLP & Machine Learning  
        - Tech Stack: Python, Scikit-learn, Streamlit, NLP (TF-IDF)
        """
    )
